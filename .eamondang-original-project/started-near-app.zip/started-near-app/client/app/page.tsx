import Content from "./Content";

export default function Home() {
  return (
    <main>
      <Content/>
    </main>
  );
}
